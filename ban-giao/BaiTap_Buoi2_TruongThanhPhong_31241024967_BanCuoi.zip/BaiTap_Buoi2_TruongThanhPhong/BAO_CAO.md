ĐẠI HỌC KINH TẾ THÀNH PHỐ HỒ CHÍ MINH

TRƯỜNG CÔNG NGHỆ VÀ THIẾT KẾ

KHOA CÔNG NGHỆ THÔNG TIN KINH DOANH

BÀI TẬP CÁ NHÂN BUỔI 2

PHÁT TRIỂN ỨNG DỤNG WEB / THƯƠNG MẠI ĐIỆN TỬ

HOÀN THIỆN GIAO DIỆN PHONG SELECT

HTML5 · CSS SELECTOR · BOX MODEL · FLEXBOX · GRID

Sinh viên: Trương Thanh Phong

Mã số sinh viên: 31241024967

Lớp: EE0002

Giảng viên trong đề: TS. Nguyễn Mạnh Tuấn

Ngày thực hiện: 22/10/2026

# MỤC LỤC

- 1. Phạm vi, yêu cầu và rà soát bài Buổi 1
- 2. Bước 2–4 — HTML5, CSS ngoài, selector và Box Model
- 3. Bước 5–7 — Flexbox, Grid, hover và focus
- 4. Bước 8 — Kiểm tra, nguyên nhân và điều chỉnh
- 5. Trả lời câu hỏi kiến thức từ mã thật
- 6. Chuẩn bị đủ năm yêu cầu sửa mã trực tiếp
- 7. Báo cáo sử dụng AI và chín khung prompt
- 8. GitHub, bàn giao, cách chạy và định hướng
- Phụ lục — Phiếu thực hành cá nhân

# 1. Phạm vi, yêu cầu và rà soát bài Buổi 1

## 1.1. Mục tiêu và phương pháp

Bài tập cá nhân Buổi 2 tiếp tục **Phong Select** từ Buổi 1 trong cùng repository. Khu vực trọng tâm là **danh sách và thẻ sản phẩm**; menu/bộ lọc được kiểm tra hồi quy để giữ hoạt động cũ. Bốn sản phẩm, giá, hình SVG và thương hiệu được kế thừa. Không tạo website khác hoặc thay bằng ví dụ ShopMate/áo thun trong đề.

Mục tiêu là thực hành HTML5 có ngữ nghĩa, liên kết CSS ngoài, selector, Box Model, Flexbox, Grid và hover/focus; biết kiểm tra, giải thích và điều chỉnh mã. Trang vẫn là HTML/CSS tĩnh, không backend, cơ sở dữ liệu, framework CSS hoặc JavaScript ứng dụng.

Tài liệu được làm cho **Trương Thanh Phong — 31241024967 — EE0002**, ngày **22/10/2026**. Trợ lý hỗ trợ đọc đề 23 trang, xem infographic, sửa tệp trực tiếp, đo/chụp bằng Chromium và soạn báo cáo. Không khai đã dùng giao diện VS Code/DevTools hoặc sinh viên đã tự sửa khi chưa có xác nhận. Phiếu cá nhân ở cuối dành cho sinh viên thực hiện yêu cầu độc lập của đề.

## 1.2. Đối chiếu tám sản phẩm phải nộp

| STT | Sản phẩm trong đề | Đáp ứng trong bài |
|---|---|---|
| 1 | HTML tiếp tục từ Buổi 1 | index.html của cùng Phong Select, giữ dữ liệu/chức năng và nâng cấu trúc danh sách. |
| 2 | CSS riêng liên kết đúng | css/style.css; HTML tải trực tiếp; root style.css giữ tương thích đường dẫn cũ. |
| 3 | Ảnh trước và sau | Cặp card-768.png trong evidence/buoi2/before và after, cùng ảnh các chiều rộng khác. |
| 4 | Ảnh giao diện cuối | catalog-1366.png, catalog-390.png và ảnh thẻ/menu/trạng thái. |
| 5 | Báo cáo kiểm thử | Mục 4, docs/buoi2/KIEM_THU.md, log ui-check.json. |
| 6 | Báo cáo AI | Mục 7 và docs/buoi2/AI_USAGE.md, đủ chín khung prompt, kết quả/đối chiếu. |
| 7 | Câu hỏi kiến thức | Mục 5: đủ bảy câu chính và bảy câu tự kiểm tra HTML/Flexbox. |
| 8 | Repository và README | Cùng repository Buổi 1, mã/tài liệu Buổi 2 đã được đẩy lên main. |

Đề dẫn “bảy câu hỏi ở phần 5” trong bảng nộp bài; bảy câu thực tế nằm ở **mục 12, trang 21**. Báo cáo trả lời theo đúng nội dung, đồng thời chuẩn bị đủ năm dạng sửa mã của mục 13. Grid là phần mở rộng nhưng đã thực hiện, đo và chụp.

## 1.3. Bước 1 — Hiện trạng và ít nhất ba vấn đề

Nguồn kế thừa là commit **dbb6bc2**. Bản cũ đã có header/nav/main/section/article/footer, một h1, h2/h3, ảnh có alt, liên kết nội bộ, Flexbox, Grid, media query và một số hover/focus. Vì vậy không mô tả sai rằng bài cũ thiếu toàn bộ các thành phần này.

| Vấn đề/cơ hội | Bằng chứng và phân loại | Hướng cải thiện | Kết quả mong muốn |
|---|---|---|---|
| Min-height ở cuối CSS ghi đè quy tắc media, tạo khoảng trống cứng. | Đã xác nhận tại 768 px: mô tả min-height 72 px, khối giá 118 px, dù media trước đặt 44/108 px. | Bỏ khai báo cạnh tranh, dùng Flexbox cột và margin-top:auto để căn khối giá. | Chiều cao nội dung linh hoạt, CSS dễ theo dõi. |
| Tập sản phẩm/menu chưa biểu diễn bằng danh sách. | Cơ hội cải thiện ngữ nghĩa; div chứa bốn article, nav chứa trực tiếp ba a. Không phải lỗi cú pháp bắt buộc. | Dùng ul/li cho tập mục, giữ article/nav, reset khoảng cách mặc định. | Ngữ nghĩa tập hợp rõ, không lệch lề hay marker. |
| Nền thao tác đổi tức thời khi hover. | Summary có transition-duration 0 s; biểu tượng có chuyển đổi riêng. Focus đã có, không nhận là thiếu hoàn toàn. | Transition màu 180 ms, hover xanh/trắng, focus-visible rõ, giữ giảm chuyển động. | Phản hồi nhìn thấy, không đổi kích thước thao tác. |

![Hình 1. Trước sửa — thẻ bàn phím ở 768 px trong bản Buổi 1. Khoảng trống giữa tên, mô tả và giá được đối chiếu với computed style, không chỉ suy đoán từ ảnh.](ma-nguon/evidence/buoi2/before/card-768.png)

Bản đo trước lưu ở `evidence/buoi2/before/baseline-check.json`; ảnh có SHA-256. Bản gốc mã HTML/CSS giữ trong lịch sử Git. Thứ tự xử lý: xác định hiện trạng → HTML/danh sách → đường dẫn CSS → Box Model → Flexbox/Grid → hover/focus → kiểm tra hồi quy → tài liệu/GitHub.

# 2. Bước 2–4 — HTML5, CSS ngoài, selector và Box Model

## 2.1. Bước 2 — Cấu trúc có ngữ nghĩa

Giữ các vùng nội dung sẵn có, chỉ chỉnh phần danh sách và menu. Mỗi sản phẩm vẫn là article, tập sản phẩm thành ul/li. Bổ sung class product-title cho tên; đổi tên plan-* cũ thành product-details/product-detail-content/product-disclaimer để mã sát nội dung.

```html
<ul id="product-grid" class="product-grid" role="list">
  <li class="product-item" data-category="input">
    <article class="product-card" aria-labelledby="ten-keyboard">
      <!-- Ảnh và vùng nội dung có h3, giá, details/summary -->
    </article>
  </li>
</ul>
```

Đây là trích đoạn rút gọn; mã đầy đủ giữ bốn ảnh/tên/giá/thao tác. Menu thành nav > ul > li > a. Head có doctype, lang=vi, UTF-8, viewport và title. H1 chỉ dùng một lần, h2 cho khu vực, h3 cho sản phẩm. Img giữ alt đúng hình; liên kết a trỏ tới phần tử có thật. Không thêm phần tử ngữ nghĩa chỉ để làm mã dài.

| Phần tử | Lý do dùng trong Phong Select |
|---|---|
| header/nav/main/footer | Phân chia đầu trang, điều hướng, nội dung chính và cuối trang. |
| section | Nhóm nội dung có chủ đề và tiêu đề. |
| article | Đơn vị thông tin một sản phẩm tương đối độc lập. |
| ul/li, ol/li | Tập sản phẩm/menu/đặc điểm và ba ý có thứ tự ở giới thiệu. |
| img/alt, a | Hình có mô tả thay thế và liên kết điều hướng thật. |
| details/summary | Mở/đóng thông tin sản phẩm bằng hành vi trình duyệt. |

Kiểm tra bằng parser và DOM: không lỗi phân tích html5lib, không ID trùng/nhảy cấp, có bốn li sản phẩm và ba li menu. Đây là kiểm tra cụ thể, không thay cho mọi kiểm định tiêu chuẩn HTML hoặc công nghệ hỗ trợ.

## 2.2. Bước 3 — Tổ chức và liên kết CSS

CSS chính chuyển vào `css/style.css`; head dùng:

```html
<link rel="stylesheet" href="css/style.css">
```

Giữ root `style.css` làm @import tương thích đường dẫn Buổi 1. HTML hiện tại chỉ tải trực tiếp tệp chính, không tải hai bản CSS đầy đủ cạnh tranh. Tệp chính giữ body margin:0, font Arial/Helvetica/sans-serif, bảng màu xanh/kem, line-height, border-box và img max-width:100%;height:auto. Không dùng Bootstrap/Tailwind hoặc CDN.

Cách kiểm tra đường dẫn: xem phần Network để chắc request css/style.css không trả 404, rồi xem Computed để xác nhận font/màu/padding. Trong phiên hỗ trợ, Playwright kiểm tra stylesheet có cssRules và giá trị thực tính. Nếu CSS mất tác dụng, cần kiểm tra đường dẫn tương đối, tên tệp/chữ hoa thường, cache và selector bị ghi đè; không sửa ngẫu nhiên nhiều nơi.

## 2.3. Bước 4 — Selector và Box Model

| Loại selector | Ví dụ thật | Phần tử bị tác động |
|---|---|---|
| Element | body, img | Nền tảng chữ/nền và ảnh co theo vùng chứa. |
| Class | .product-card | Viền, góc, nền và bố cục của thẻ. |
| Descendant | .product-card .product-title | Tên sản phẩm bên trong thẻ. |
| Descendant | .product-card .product-toggle | Thao tác xem thông tin trong thẻ. |
| Pseudo-class | :hover, :focus-visible | Trạng thái chuột và điều hướng bàn phím. |

```css
* { box-sizing: border-box; }
.product-card {
  margin: 0;
  border: 1px solid var(--line);
  border-radius: 18px;
}
.product-content { padding: 24px; }
.product-description { margin-bottom: 20px; }
```

Margin là khoảng phía ngoài viền; padding ở bên trong; border là viền; border-radius bo góc. Padding nằm trên `.product-content` để ảnh vẫn sát viền trên của article; ở ≤580 px là 20 px. Khoảng giữa các thẻ do Grid gap 24 px, không cộng margin tùy ý lên từng li.

Tại 1366 px: article rộng 302 px; hai viền 1 px còn 300 px cho vùng con. Vùng `.product-content` có padding 24 px mỗi bên nên nội dung còn **300 − 48 = 252 px**. Border-box tính padding/viền vào kích thước được khai báo của chính phần tử; cần phân biệt hộp cha và hộp con khi giải thích.

Phần liên kết sản phẩm dùng `a.product-image-link` mở SVG thật của từng mặt hàng trong tab mới. CSS descendant `.product-card .product-image-link` định dạng thành thao tác đơn giản với display:inline-block, `padding:8px 12px`, viền 1 px, bo góc 6 px và hover nền nhạt; focus kế thừa từ a:focus-visible. Đã click và xác minh đủ bốn đích ảnh, không tạo trang chi tiết hoặc liên kết mua hàng giả.

![Hình 2. Sau sửa — cùng thẻ ở 768 px. Mô tả đo khoảng 47,59 px theo nội dung, thay min-height 72 px; padding nội dung 24 px. Ảnh giữ trọn tỷ lệ 4/3.](ma-nguon/evidence/buoi2/after/card-768.png)

# 3. Bước 5–7 — Flexbox, Grid, hover và focus

## 3.1. Bước 5 — Flexbox trên khu vực nhỏ

Summary chứa hai span: nhãn “Xem thông tin” và ký hiệu +. Đây là khu vực hai phần tử phù hợp thực hành Flexbox:

```css
.product-card .product-toggle {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}
```

Với flex-direction mặc định row, justify-content theo trục ngang; align-items theo trục dọc. Space-between đưa hai mục về hai đầu vùng nội dung; gap 12 px không đồng nghĩa khoảng thực tế luôn 12 px, vì phần trống còn được phân phối.

| Giá trị thử | Quan sát tại 1366 px | Quyết định |
|---|---|---|
| flex-start | Cặp nhãn/+ về đầu, khoảng giữa 12 px. | Lưu ảnh thí nghiệm. |
| center | Cặp nhãn/+ ở giữa, khoảng giữa 12 px. | Lưu ảnh thí nghiệm. |
| space-between | Hai mục về hai đầu; khoảng thực tế khoảng 129,73 px. | Giữ cho thao tác cuối. |

Menu cũng dùng Flexbox ở ul.main-nav-list: flex-wrap, căn và gap. Trong thẻ, product-card/product-content dùng flex-direction:column; margin-top:auto ở khối giá nhận phần trống còn lại để căn, thay min-height cứng.

![Hình 3. Menu sau sửa: nav chứa danh sách ul/li; Flexbox ở ul sắp xếp các liên kết. Các đích điều hướng của Buổi 1 được giữ.](ma-nguon/evidence/buoi2/after/header.png)

## 3.2. Bước 6 — Grid mở rộng, thử cột và giữ tỷ lệ ảnh

Danh sách tiếp tục bốn sản phẩm cũ. Đã thử repeat(2,...) và repeat(3,...): tại viewport 1366 px, vùng lưới 1280 px/gap 24 px cho hai cột 628 px và ba cột khoảng 410,66 px. Cấu hình cuối giữ bốn cột ở >1100 px, hai cột ở >580–1100 px, một cột ở ≤580 px.

```css
.product-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 24px;
  list-style: none;
  padding: 0;
  margin: 0;
}
```

Repeat lặp định nghĩa cột; 1fr chia phần không gian còn lại; minmax(0,1fr) cho cột co trong vùng chứa; gap tạo rãnh giữa hàng/cột. Reset ul tránh marker và padding trái mặc định. Li là phần tử Grid, vì vậy điều kiện lọc ẩn li để bỏ cả ô. Đây là điều chỉnh bắt buộc khi thay cấu trúc; nguy cơ ô trống được phòng tránh, không ghi thành lỗi đã xảy ra nếu chưa tái hiện.

Ảnh SVG gốc 640 × 480; CSS giữ aspect-ratio 4/3 và object-fit:contain. Cover lấp đầy khung nhưng có thể cắt ảnh khi khác tỷ lệ; contain được chọn để giữ trọn minh họa. Không chép cover từ ví dụ rồi làm mất một phần sản phẩm.

![Hình 4. Thí nghiệm Grid ba cột trên dữ liệu cũ; ảnh được ghi riêng, không phải cấu hình cuối. Ảnh thử hai cột cũng có trong gói minh chứng.](ma-nguon/evidence/buoi2/after/grid-3-columns.png)

![Hình 5. Khu vực danh sách hoàn thiện trên 1366 px: bốn sản phẩm, lưới bốn cột, bộ lọc/đặt lại được giữ và các thẻ có thông tin giá/thao tác.](ma-nguon/evidence/buoi2/after/catalog-1366.png)

## 3.3. Bước 7 — Hover, transition và focus

Thao tác dùng nền trắng/chữ xanh; hover chuyển nền xanh/chữ trắng. Transition màu 180 ms tạo phản hồi nhẹ; không đổi padding/viền dày hoặc kích thước nên chiều cao vẫn 48 px. Focus-visible có outline solid 3 px, offset 3 px để nhận biết khi dùng bàn phím. Hover là con trỏ ở trên phần tử; focus là phần tử nhận thao tác bàn phím, không được coi hai trạng thái là một.

```css
.product-card .product-toggle {
  transition: background-color 180ms ease,
              color 180ms ease, border-color 180ms ease;
}
.product-card .product-toggle:hover {
  background: var(--accent);
  color: white;
}
.product-card .product-toggle:focus-visible {
  outline: 3px solid #81520c;
  outline-offset: 3px;
}
```

![Hình 6. Trạng thái hover thực: nền xanh/chữ trắng, chiều cao không đổi.](ma-nguon/evidence/buoi2/after/state-hover.png)

![Hình 7. Trạng thái focus-visible thực khi điều hướng bằng bàn phím: viền rõ quanh summary.](ma-nguon/evidence/buoi2/after/state-focus.png)

Quy tắc prefers-reduced-motion kế thừa có hiệu lực: khi reduce, transition trở về 0 s. Nhãn đầy đủ trong summary phân biệt sản phẩm; Enter mở/đóng thông tin, không mô phỏng thêm giỏ hoặc mua hàng.

# 4. Bước 8 — Kiểm tra, nguyên nhân và điều chỉnh

## 4.1. Phương pháp và phạm vi

Chromium 154.0.8037.57, Playwright, html5lib 1.1 và axe-core 4.10.3 kiểm tra trang qua HTTP từ checkout. Công cụ chỉ dùng trong quá trình đo, không tải vào website. Các thí nghiệm thay CSS/alt chỉ tồn tại trong DOM trình duyệt và được khôi phục; không cộng các biến thể thử vào mã cuối.

Ba chiều rộng đề gợi ý 1366/768/390 px đều được kiểm tra; thêm 1440/1024/375/320 px. Log có thời điểmUTC, số đo, trạng thái, lỗi và SHA-256 bốn tệp nguồn; ảnh cuối được chụp với con trỏ ngoài nút để tránh nhầm hover.

## 4.2. Bảng kiểm thử theo đề

| Nội dung | Kết quả | Ghi chú |
|---|---|---|
| HTML mở được | Đạt | HTTP 200, đúng nội dung và bốn sản phẩm. |
| CSS áp dụng | Đạt | css/style.css tải đúng, đọc được cssRules và computed style. |
| Ảnh đúng | Đạt | Bốn ảnh có alt, tải đủ 640 × 480, tỷ lệ 4/3 không méo. |
| Liên kết | Đạt trong phạm vi thử | Fragment có đích, menu tới#san-pham; không nhận là đã kiểm thử giao dịch Lazada. |
| Không tràn nghiêm trọng | Đạt | Bảy độ rộng; documentWidth không vượt viewport. |
| Hover/focus | Đạt | Chuyển màu, focus 3 px, chiều cao 48 px không đổi. |
| Sinh viên tự sửa một điểm | Chờ sinh viên xác nhận | Trợ lý đã sửa/đo; yêu cầu độc lập cần thao tác thật của sinh viên. |

## 4.3. Kết quả chức năng và kiểm tra bổ sung

| Hạng mục | Kết quả |
|---|---|
| Lưới tại 1440/1366/1024/768/390/375/320 px | 4/4/2/2/1/1/1 cột; không tràn ngang. |
| Lọc 3 nhóm × 7 chiều rộng | 21/21 đúng nhóm/số lượng 2/1/1; cả li và article hiển thị đúng. |
| Đặt lại | 7/7 khôi phục bốn thẻ. |
| Bàn phím | 4/4 chi tiết mở/đóng bằng Enter; radio bằng ArrowRight; reset bằng Enter. |
| HTML/DOM | 0 lỗi phân tích; một h1, không nhảy cấp hoặc ID trùng, bốn li sản phẩm/ba li menu. |
| Flexbox/Grid | Ba justify-content; Grid 2/3 cột; thử bỏ Grid và quan sát xếp dọc. |
| Luyện sửa | Đã thử đủ năm tình huống của mục 13, chỉ trên DOM/CSS tạm. |
| Liên kết sản phẩm | Bốn nút Xem hình lớn mở đúng SVG của từng sản phẩm trong tab mới. |
| Giá | Hiển thị khớp products.json, tỷ lệ 20/20/15/20% đúng. |
| Lỗi trong lượt thử | Không có lỗi JavaScript hoặc phản hồi HTTP lỗi; 0 script ứng dụng trước khi chèn công cụ đo. |
| Axe | 31 quy tắc đạt, 0 vi phạm phát hiện, 1 quy tắc chưa kết luận tự động. |

Quy tắc chưa kết luận liên quan bốn ký hiệu ₫. Đối chiếu màu thực tính rgb(24,60,53) trên nền trắng bằng công thức độ chói cho tương phản **12,09:1**, vượt 4,5:1. Đây là kiểm tra bổ sung các ký hiệu; không phải chứng nhận WCAG. Chưa kiểm tra mọi Safari/Firefox, thiết bị thật, trình đọc màn hình hoặc hiệu quả người mua; thông báo aria-live khi đổi hiển thị bằng CSS chưa được xác minh trên từng công nghệ hỗ trợ.

## 4.4. Vấn đề, nguyên nhân và cách khắc phục

Vấn đề đã xác nhận là các min-height cùng selector ở cuối file ghi đè giá trị trong media trước. Cách sửa là bỏ các chiều cao tối thiểu cạnh tranh, tổ chức quy tắc gốc trước media và dùng Flexbox cột/margin-top:auto. Ở 768 px, mô tả cuối khoảng 47,59 px theo nội dung; thẻ đầu đo 604,17 px so với 622,06 px trước. Đây là số đo bố cục của một thẻ, không suy thành mức tăng hiệu quả mua sắm.

Việc bổ sung danh sách và transition là cải thiện có chủ đích, không biến thành lời kết luận rằng HTML cũ sai hoặc không có focus. Sau khi đổi HTML, đã kiểm tra lọc trên li để giữ hành vi cũ. Bảng và ảnh minh chứng ở evidence/buoi2, kiểm tra tái chạy tùy chọn trong tools/README.md.

## 4.5. Đính chính và kiểm chứng ở lượt rà soát cuối

Lượt rà soát cuối bổ sung 14 chiều rộng, gồm các mốc sát 580/581 px và 1100/1101 px, kiểm tra cả trạng thái đóng và mở thông tin. Không phát hiện tràn ngang hoặc lỗi chức năng trong phạm vi đã đo. Bộ kiểm thử cơ sở gồm 21 tình huống được chạy lại; bổ sung đối chiếu đầy đủ giá bán, giá cũ, tiền tiết kiệm, tỷ lệ hiển thị và axe khi mở tất cả thông tin. Log mới ở evidence/buoi2/final-review, vẫn phân biệt phạm vi đã thử với thiết bị/trình đọc màn hình chưa kiểm chứng.

Đã sửa một nhận định chưa đủ chính xác trong hướng dẫn Box Model: tăng padding 24→28 px vẫn giữ khung ngoài 300 px trong bố cục width:auto còn do Flexbox kéo giãn theo trục ngang, không chỉ do border-box. Thử riêng width:100%/padding 28 px cho kết quả border-box 300 px và content-box 356 px. Các đáp án/hướng dẫn sửa trực tiếp đã cập nhật theo phép đo; không lưu cấu hình thử vào trang. Đồng thời chuẩn hóa khoảng trắng của phần diễn giải, giữ nguyên mã nguồn minh họa và nội dung trích dẫn.

![Hình 8. Thẻ trên 390 px sau hoàn thiện: padding 20 px, ảnh đúng tỷ lệ, nội dung và thao tác không tràn ngang. Ảnh toàn danh sách điện thoại có trong gói.](ma-nguon/evidence/buoi2/after/card-390.png)

Phần tự mở, tự phát hiện/sửa và giải thích của sinh viên chưa được xác nhận thay. Phiếu cuối báo cáo/TU_KIEM_TRA.md dùng ghi kết quả cá nhân; không đổi người thực hiện của các log đã có.

# 5. Trả lời câu hỏi kiến thức từ mã thật

## 5.1. Bảy câu hỏi chính — mục 12 của đề

### Câu 1. Các phần tử HTML5 đã sử dụng và lý do lựa chọn

- `header`: chứa thương hiệu và điều hướng đầu trang.
- `nav`: xác định khu vực liên kết điều hướng chính, có `aria-label`.
- `main`: vùng nội dung chính; liên kết bỏ qua đầu trang trỏ tới vùng này.
- `section`: nhóm nội dung giới thiệu, sản phẩm, cải tiến và thông tin bài; mỗi nhóm có tiêu đề.
- `article.product-card`: một sản phẩm có nội dung tương đối độc lập: ảnh, tên, giá, mô tả và thao tác.
- `footer`: thông tin cuối trang và liên kết về đầu trang.
- `h1/h2/h3`: lần lượt là tiêu đề trang, khu vực và từng sản phẩm; chỉ có một h1 và không nhảy cấp trong lượt kiểm tra.
- `ul > li`: biểu diễn tập sản phẩm và các mục menu; bên trong mỗi li sản phẩm vẫn có article. Các đặc điểm trong phần thông tin mở rộng cũng là danh sách ul/li. Danh sách ol ở khu vực giới thiệu thể hiện ba ý có thứ tự.
- `img` có `alt`: hình sản phẩm và mô tả thay thế; các hình giữ chiều rộng/cao gốc 640 × 480.
- `a`: điều hướng tới vị trí có thật như `#san-pham`, `#cai-tien`, `#thong-tin`, không dùng href giả để mô phỏng mua hàng. Trong thông tin sản phẩm còn có a.product-image-link mở đúng hình SVG lớn của mặt hàng.
- `details/summary`: thao tác mở/đóng thông tin có hành vi gốc, dùng được bằng Enter.
- `form/fieldset/legend/label/input` và `button type=reset`: nhóm lọc có tên và lựa chọn, đặt lại được.

Ví dụ rút gọn từ cấu trúc thật:

```html
<ul id="product-grid" class="product-grid" role="list">
  <li class="product-item" data-category="input">
    <article class="product-card" aria-labelledby="ten-keyboard">
      <!-- Ảnh, h3, giá và details/summary của sản phẩm -->
    </article>
  </li>
</ul>
```

Không thêm header, nav hoặc section vào mọi thẻ chỉ để tăng số phần tử. Phần chỉ phục vụ bố cục như `.product-content` vẫn dùng div.

### Câu 2. Margin và padding; ví dụ từ thẻ sản phẩm

**Padding** tạo khoảng trống phía trong viền của hộp. `.product-content { padding:24px; }` chừa chỗ quanh nội dung; ở màn hình ≤580 px là 20 px. Padding đặt trên vùng nội dung con để ảnh vẫn sát phần viền trên của article.

**Margin** tạo khoảng cách phía ngoài viền của phần tử. `.product-description { margin-bottom:20px; }` tạo khoảng cách sau mô tả; `.price-block { margin-bottom:18px; }` tạo khoảng cách tới thao tác. `.product-card` đặt margin:0; khoảng cách giữa các thẻ do Grid gap:24px quản lý, tránh cộng dồn khoảng cách.

**Border** là viền: article có border:1px solid và border-radius:18px. **border-box** làm width bao gồm padding và border của chính hộp đó, tránh tăng chiều rộng ngoài dự tính.

Tại 1366 px, đo thực tế: article rộng 302 px; hai viền chiếm 2 px; vùng `.product-content` rộng ngoài 300 px; trừ padding 24 × 2 còn **252 px** cho nội dung. Không nói article có padding 24 px: padding nằm ở phần tử con `.product-content`.

Cần phân biệt cơ chế tính kích thước: trong bố cục này `.product-content` có width:auto và được Flexbox kéo giãn theo trục ngang, nên tăng padding 24→28 px vẫn giữ khung ngoài 300 px cả khi thử content-box. Khi thử riêng width:100% và padding 28 px, border-box giữ 300 px còn content-box thành 356 px. Vì vậy không dùng hiện tượng width:auto để kết luận rằng chỉ border-box mới giữ được chiều rộng ngoài.

### Câu 3. Flexbox dùng ở đâu; justify-content và align-items

Flexbox dùng ở `.header-content`, `.main-nav-list`, `.product-card`, `.product-content`, `.price` và thao tác `.product-toggle`.

Ví dụ tập trung của Buổi 2:

```css
.product-card .product-toggle {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}
```

Phần tử cha summary chứa hai span: nhãn và ký hiệu +. Với hướng mặc định row, `justify-content` sắp xếp theo trục ngang; `align-items:center` căn theo trục dọc. `space-between` đẩy hai mục về hai đầu vùng nội dung. `gap:12px` là khoảng cách bố trí tối thiểu giữa chúng; khoảng cách nhìn thấy có thể lớn hơn do phần trống được space-between phân phối.

Đã thử `flex-start`, `center`, `space-between`: hai trường hợp đầu có khoảng cách giữa hai mục là 12 px; trường hợp cuối khoảng 129,73 px tại chiều rộng đo 1366 px. Thử nghiệm chỉ đổi style trong trình duyệt, không lưu ba cấu hình cạnh tranh vào CSS cuối.

Trong `.product-content`, hướng flex là column; `margin-top:auto` ở `.price-block` nhận phần trống còn lại để căn khối giá, thay cách đặt min-height cố định cho nhiều đoạn.

### Câu 4. CSS Grid khác Flexbox; lý do chọn Grid

Flexbox tổ chức theo một trục chính, phù hợp menu, nhãn/biểu tượng hoặc nội dung dọc trong thẻ. Grid thiết lập đồng thời cấu trúc hàng/cột, phù hợp các thẻ cần nằm theo những cột thống nhất. Flexbox có thể xuống dòng, nhưng các dòng không tự dùng chung hệ cột như Grid.

`.product-grid` dùng `display:grid`, `grid-template-columns:repeat(4,minmax(0,1fr))`, `gap:24px`. Khi ≤1100 px chuyển hai cột; ≤580 px chuyển một cột. Đã thử hai và ba cột riêng; cấu hình cuối giữ 4/2/1 phù hợp bốn sản phẩm kế thừa từ Buổi 1.

`repeat()` lặp định nghĩa cột; `1fr` chia đều phần không gian còn lại; `minmax(0,1fr)` cho cột co lại trong vùng chứa. Gap tạo rãnh giữa hàng/cột.

### Câu 5. Nếu xóa display:grid

Trong cấu trúc thật, ul sẽ trở về bố cục block thông thường nếu không còn quy tắc đặt display:grid. Các li sản phẩm vốn là hộp flex dạng block sẽ xếp dọc, không còn chia thành các cột bằng nhau. `grid-template-columns` không còn tạo lưới; gap cũng không tạo các rãnh Grid như trước.

Đã thử bằng cách tạm đổi display:block trên chính ul. Hai mục đầu có cùng tọa độ trái và mục thứ hai nằm phía dưới mục thứ nhất. Đây là quan sát trong trình duyệt, không phải cấu hình cuối được lưu.

### Câu 6. Vì sao ảnh cần alt

Alt mô tả ý nghĩa của hình cho người không nhìn thấy ảnh, trình đọc màn hình hoặc khi ảnh không tải. Trong bài, alt đầu tiên là “Minh họa bàn phím cơ K75 nhỏ gọn, phím màu kem và điểm nhấn xanh”. Mô tả khớp hình SVG, không lấy tên tệp hoặc nhồi từ khóa.

Alt không thay thế việc kiểm tra đường dẫn src. Hình thuần trang trí có thể dùng alt rỗng phù hợp, nhưng bốn hình sản phẩm mang thông tin nên dùng mô tả có nội dung. SVG biểu tượng trang trí trong nút được ẩn khỏi công nghệ hỗ trợ bằng aria-hidden.

### Câu 7. Một đề xuất AI đã kiểm tra hoặc điều chỉnh

Đề xuất cụ thể là chuyển danh sách từ div chứa trực tiếp article thành **ul > li > article** để thể hiện tập sản phẩm. Khi áp dụng, selector lọc phải chọn `.product-item` trên li thay vì chỉ ẩn `.product-card` bên trong: nếu chỉ ẩn article, một li rỗng vẫn có thể chiếm ô Grid.

Mã cuối đã chuyển data-category và điều kiện lọc sang li, sau đó kiểm tra **21 tình huống lọc trên bảy chiều rộng**; số mục hiển thị và thẻ cùng đúng 2/1/1. Đây là kiểm chứng do trợ lý thực hiện. Sinh viên có thể dùng ví dụ này sau khi tự đọc, thao tác và giải thích; không khai rằng đã tự thực hiện nếu chưa làm.

## 5.2. Bốn câu tự kiểm tra HTML — bước 2

1. **Vì sao dùng nav?** Nó đặt tên ngữ nghĩa cho vùng điều hướng; trong bài là ba liên kết đầu trang. Không dùng nav cho mọi nhóm liên kết nhỏ trong thẻ.
2. **Article khác div?** Article thể hiện đơn vị nội dung tương đối độc lập; div là vùng chứa không mang ngữ nghĩa chuyên biệt. Sản phẩm dùng article, phần bố trí ảnh/nội dung dùng div.
3. **Vì sao cần alt?** Tham khảo câu 6: cung cấp mô tả thay thế đúng nội dung, không chỉ để hết cảnh báo công cụ.
4. **Khi nào dùng ul/li?** Khi nội dung là tập các mục không có thứ tự bắt buộc: sản phẩm, menu, đặc điểm. Khi trình tự có ý nghĩa có thể dùng ol/li như ba ý trong khu vực giới thiệu.

## 5.3. Ba câu tự kiểm tra Flexbox — bước 5

1. **Display:flex đặt ở đâu?** Đặt trên phần tử cha có các phần tử con trực tiếp cần bố trí; ví dụ summary chứa hai span hoặc ul.main-nav-list chứa ba li.
2. **Space-between bố trí thế nào?** Mục đầu ở đầu vùng nội dung, mục cuối ở cuối; phần trống được chia giữa các mục. Không tự thêm khoảng trống ở hai mép như space-around.
3. **Gap khác margin?** Gap đặt trên cha, tạo khoảng cách giữa các mục, không tạo khoảng cách ngoài mép container. Margin đặt trên từng phần tử và còn có thể tạo khoảng cách phía ngoài; trong thẻ có margin của đoạn mô tả. Không cộng margin vào li chỉ để lặp lại gap đã có.

## 5.4. Bổ sung object-fit

`object-fit:cover` lấp đầy khung nhưng có thể cắt ảnh nếu tỷ lệ khác khung. Bài giữ `contain` với tỷ lệ 4/3 để hiển thị trọn hình minh họa 640 × 480. Việc chọn contain có lý do theo tài sản thực tế, không chép cover trong ví dụ rồi để sản phẩm bị cắt.


# 6. Chuẩn bị đủ năm yêu cầu sửa mã trực tiếp

Mở `index.html` và **css/style.css**. `style.css` ở gốc chỉ là tệp tương thích đường dẫn Buổi 1, không phải nơi sửa chính. Dự đoán kết quả trước, sửa một giá trị, lưu rồi tải lại trang. Các thử nghiệm trong `evidence/buoi2/after/ui-check.json` đã do trợ lý chạy trên DOM/CSS của trình duyệt; sinh viên cần tự luyện trong editor.

## 6.1. Thay khoảng cách bên trong thẻ

Tìm `.product-content { ... padding:24px; }`, đổi thành `padding:28px`. Tại 1366 px, vùng nội dung giảm từ 252 xuống 244 px, còn khung rộng ngoài vẫn 300 px. Trong bố cục hiện tại, phần tử có `width:auto` và được Flexbox kéo giãn theo chiều ngang; không quy việc giữ chiều rộng ngoài chỉ cho `border-box`. Ở màn hình ≤580 px còn quy tắc padding:20px phía sau: nếu muốn thay riêng điện thoại phải sửa quy tắc media đó, tránh tưởng CSS không áp dụng.

Để phân biệt hai cơ chế, đã thử riêng `width:100%` với padding 28 px: border-box cho chiều rộng ngoài 300 px; content-box cho 356 px vì cộng thêm 56 px padding. Đây là thí nghiệm tạm, không phải cấu hình lưu trong trang.

Kiểm tra: chữ cách mép nhiều hơn, ảnh vẫn sát viền vì padding ở vùng nội dung; không xuất hiện cuộn ngang. Hoàn nguyên về 24 px sau thử nếu không chọn làm thay đổi cuối.

## 6.2. Đổi màu giá

Tìm `.price-value`, bổ sung `color:#b33126` hoặc dùng `.product-card .price-value { color:#b33126; }`. Kết quả dự kiến chỉ giá hiện tại đổi sang đỏ đậm; giá cũ và mô tả không đổi. Kiểm tra màu trong Computed và độ tương phản trên nền trắng. Đã thử và đọc được rgb(179,49,38). Cấu hình cuối vẫn dùng xanh đậm kế thừa từ trang.

## 6.3. Thay số cột

Tại quy tắc gốc `.product-grid`, thử:

```css
grid-template-columns: repeat(2, minmax(0, 1fr));
```

Sau đó thử repeat(3,...). Đã quan sát hai cột khoảng 628 px và ba cột khoảng 410,66 px ở viewport 1366 px. Gap vẫn 24 px. Ở màn hình ≤1100 hoặc ≤580, quy tắc media phía sau có thể ghi đè số cột; muốn xem thử gốc hãy dùng màn hình rộng hoặc sửa đúng media.

Không xóa display:grid khi chỉ muốn đổi số cột. Cấu hình cuối là 4/2/1; ảnh thử hai và ba cột được ghi riêng.

## 6.4. Đổi khoảng cách menu

Tìm `.main-nav-list { ... gap:8px 27px; }`, đổi thành `gap:8px 36px` để tăng khoảng cách ngang. `.main-nav-list` mới là cha flex chứa ba li; `.main-nav` là vùng nav bao ngoài. Kiểm tra các liên kết tách xa hơn và vẫn xuống dòng khi cần. Quy tắc cho màn hình nhỏ có thể ghi đè gap; kiểm tra đúng viewport.

## 6.5. Bổ sung/sửa alt

Trong img đầu tiên, đổi alt thành một mô tả đúng hình, ví dụ “Bàn phím cơ K75 mẫu, phím màu kem và xanh”. Giữ nguyên src. Kiểm tra trong DOM rằng alt đã đổi; giao diện nhìn thấy có thể không đổi vì ảnh vẫn tải bình thường. Không tạo alt bằng giá bán hoặc thông tin không có trong hình.

## 6.6. Quy trình giải thích trước giảng viên

1. Chỉ phần tử/class cần sửa và tệp chứa nó.
2. Nêu thuộc tính, giá trị hiện tại, giá trị dự định thay và dự đoán.
3. Sửa, lưu, tải lại; kiểm tra đúng media query và trạng thái hover/focus nếu có.
4. Đối chiếu với dự đoán, giải thích vì sao nếu khác.
5. Ghi thay đổi cá nhân và bằng chứng vào TU_KIEM_TRA.md; commit nếu giữ làm bản chính.


# 7. Báo cáo sử dụng AI và chín khung prompt

## 7.1. Công cụ, đầu vào và vai trò

OpenAI ChatGPT/Codex hỗ trợ đọc đề, phân tích mã, tạo phương án, sửa tệp, chạy công cụ, chụp ảnh và soạn báo cáo. Đầu vào là đề Buổi 2, mã Phong Select ở commit dbb6bc2 và yêu cầu thực tế của người dùng hoàn thành lần lượt các công việc. Phần sinh viên tự chạy/tự sửa cần bổ sung bằng trải nghiệm thật.

Chín khung dưới được trợ lý áp dụng theo đề trong phiên làm việc; không trình bày thành chín tin nhắn độc lập do sinh viên gửi, không tạo ảnh hội thoại giả. Mã đầu vào/đầu ra đối chiếu qua lịch sử Git; log đầy đủ trong docs/buoi2/AI_USAGE.md.

## Prompt 1 — Phân tích mã hiện tại

> Phân tích index.html và style.css của Phong Select ở commit dbb6bc2. Nêu thành phần đã có, ít nhất ba vấn đề/cơ hội cải thiện, hướng sửa và thứ tự thực hiện bằng HTML5/CSS3. Không tạo website mới, không viết lại toàn bộ; phân biệt lỗi đã xác nhận và đề xuất cải thiện.

Kết quả: đã có HTML ngữ nghĩa, alt, Grid, Flexbox và responsive. Xác nhận min-height cuối CSS ghi đè giá trị của media tại 768 px; đề xuất ul/li cho tập sản phẩm/menu và transition cho nền summary vốn 0 s. Không gán lỗi “thiếu alt/thiếu header/chưa responsive” cho bài cũ.

## Prompt 2 — Kiểm tra HTML5

> Rà soát doctype, lang, charset, viewport, header/nav/main/section/article/footer, h1–h3, img/alt, a và danh sách. Sửa cấu trúc tập sản phẩm theo nội dung thực tế; giữ article cho từng thẻ, không thêm phần tử vô nghĩa. Giải thích lý do và kiểm tra thẻ đóng/lồng nhau.

Kết quả: sản phẩm thành ul > li > article; menu thành nav > ul > li > a; có class rõ cho tên và thao tác; alt đầu tiên cụ thể hơn. Trình phân tích html5lib ghi nhận 0 lỗi phân tích; kiểm tra DOM cho một h1, không nhảy cấp/ID trùng, bốn li và ba mục menu.

## Prompt 3 — Liên kết CSS ngoài

> CSS Buổi 1 ở gốc style.css. Tạo css/style.css làm tệp chính, cập nhật link trong head, giữ đường dẫn cũ tương thích và tránh hai bản CSS đầy đủ cạnh tranh. Giữ font Arial, bảng màu hiện có, body margin:0, border-box và ảnh co theo vùng chứa; không Bootstrap/Tailwind.

Kết quả: HTML tải trực tiếp css/style.css; root style.css chỉ @import để tương thích nếu dùng đường dẫn cũ. Trình duyệt xác minh stylesheet tải và có cssRules, font/màu được áp dụng; không có thư viện CSS bên ngoài.

## Prompt 4 — Selector và Box Model

> Trên thẻ có sẵn, minh họa element selector, class selector và descendant selector. Dùng border/radius ở product-card, padding ở product-content và margin ở đoạn mô tả/khối giá; giải thích border-box theo số đo thực tế. Không tạo lại nội dung sản phẩm.

Kết quả: body/img là element selector; product-card là class selector; .product-card .product-title và .product-card .product-toggle là descendant selector. Đo tại 1366 px: thẻ 302 px, viền 1 px mỗi bên, vùng nội dung rộng ngoài 300 px, padding 24 px mỗi bên, nội dung 252 px. Tránh nhầm padding con là padding của article. Liên kết a.product-image-link được định dạng thành thao tác Xem hình lớn và thử mở đủ bốn SVG tương ứng.

## Prompt 5 — Flexbox

> Dùng summary có hai span (nhãn và +) làm khu vực Flexbox nhỏ. Giải thích display:flex, justify-content, align-items và gap. Thử flex-start, center, space-between, ghi kết quả rồi chọn cấu hình phù hợp. Không viết lại header hay toàn trang.

Kết quả: ba cấu hình được thử trên DOM; giữ space-between, align-items:center, gap:12px. Gap tối thiểu 12 px, khoảng thực tế với space-between lớn hơn do phân phối khoảng trống. Flexbox cột trong thẻ và margin-top:auto thay min-height cứng để căn khối giá.

## Prompt 6 — Grid

> Dùng danh sách bốn sản phẩm cũ, thử hai và ba cột bằng repeat/minmax, điều chỉnh gap, giữ hình đúng tỷ lệ. Giải thích display:grid, grid-template-columns, repeat, gap và object-fit:cover; chọn cover/contain phù hợp ảnh thật và nêu lý do.

Kết quả: có ảnh thử hai/ba cột; cuối cùng giữ 4/2/1 theo màn hình. Dùng contain và tỷ lệ 4/3 để không cắt SVG. Thử display:block để quan sát câu hỏi khi bỏ Grid. Không gán các thí nghiệm DOM này là cấu hình chính đã lưu.

## Prompt 7 — Hover và focus

> Bổ sung chuyển màu hover nhẹ cho product-toggle, transition 180ms, focus-visible rõ khi dùng bàn phím; không làm đổi kích thước thao tác. Kiểm tra chế độ giảm chuyển động và tương phản, giữ hành vi details/summary.

Kết quả: nền trắng/chữ xanh chuyển thành nền xanh/chữ trắng, chiều cao vẫn 48 px. Focus viền solid 3 px, offset 3 px. Reduced-motion đưa transition về 0 s. Công cụ tiếp cận và đối chiếu màu bổ sung được ghi riêng, không nhận là chứng nhận WCAG.

## Prompt 8 — Kiểm tra và sửa ít thay đổi

> Mô tả ở 768 px vẫn min-height 72px dù media trước đặt 44px; khối giá vẫn 118px thay 108px. Xác định nguyên nhân từ thứ tự CSS, đề xuất sửa tối thiểu và kiểm tra lại. Phân biệt điều đã đo và rủi ro cần phòng tránh khi đổi HTML.

Kết quả: các khai báo cùng selector ở cuối file đã ghi đè quy tắc media. Bỏ các min-height cạnh tranh, dùng bố cục flex. Sau sửa mô tả khoảng 47,59 px theo nội dung. Đồng thời chuyển lọc sang li để phòng ô trống sau khi thêm ul/li. Kiểm tra bảy chiều rộng, 21 tình huống lọc, đặt lại, ảnh, liên kết và bàn phím đều đạt trong lượt thử.

## Prompt 9 — Hoàn thiện README

> Cập nhật README cho Buổi 2, nêu rõ tiếp tục Phong Select từ Buổi 1; khu vực cải thiện; HTML/selector/Box Model/Flexbox/Grid/hover/focus; cách chạy; thay đổi; AI và cách kiểm chứng; đường dẫn repo/website nếu đã triển khai. Không bịa trạng thái Pages hoặc phần sinh viên chưa tự làm.

Kết quả: README trỏ tới hồ sơ Buổi 2, câu hỏi kiến thức, bài sửa trực tiếp, kiểm thử và báo cáo; giữ liên kết hồ sơ Buổi 1. Repo và Pages có trạng thái riêng; hoạt động cá nhân chưa được xác nhận thay.


## 7.2. Các quyết định kiểm chứng quan trọng

Giữ website/dữ liệu cũ; không dùng đề xuất tạo website mới hoặc thêm framework/JavaScript. Bổ sung ul/li sau khi kiểm tra ngữ nghĩa và cập nhật lọc theo li. Thay min-height cứng sau đo CSS thực. Chọn contain thay cover để giữ toàn hình. Giữ sự phân biệt hover/focus cũ đã có với transition mới bổ sung. Không nhận giá/số đếm tự lấy từ JSON, không nhận kiểm thử công cụ là sinh viên tự làm.

# 8. GitHub, bàn giao, cách chạy và định hướng

## 8.1. Cập nhật cùng repository

Repository Public: https://github.com/phong26052006-design/BT_canhanPTUDTMDT

Commit mã Buổi 2: **afdd5c8** — [Complete session 2 HTML5 semantics and CSS layout practice](https://github.com/phong26052006-design/BT_canhanPTUDTMDT/commit/afdd5c8a42352d0ca484881719483fa0c93c7efa). Đã đẩy thành công lên main và xác minh cây tệp có index.html, css/style.css và hồ sơ Buổi 2. Báo cáo Word được lưu bổ sung trong bao-cao/; các commit tài liệu sau không thay đổi mã giao diện đã kiểm thử. Buổi 1 vẫn giữ trong lịch sử và tệp báo cáo cũ.

API đọc Pages ngày 22/10 trả 404; chưa xác nhận có website Pages hoạt động. Hạn chế tạo Pages của tích hợp đã ghi ở phiên 20/10; không coi repository Public là đã triển khai giao diện. Bài này công khai mã và báo cáo; muốn dùng Pages cần vào Settings → Pages → Deploy from a branch → main → /(root) → Save, chờ rồi mở URL thật để kiểm tra.

## 8.2. Cấu trúc gói bài

```text
BaiTap_Buoi2_TruongThanhPhong_31241024967.docx / .pdf
BAO_CAO.md / BAO_CAO.html
HUONG_DAN_BAN_GIAO.md
ma-nguon/
  index.html
  css/style.css
  style.css                 Tương thích đường dẫn Buổi1
  images/                   SVG kế thừa
  products.json             Đối chiếu giá
  docs/buoi2/               Câu hỏi, sửa trực tiếp, AI, kiểm thử
  evidence/buoi2/           Trước/sau, thí nghiệm và log
  bao-cao/                  Báo cáo Word công khai
  tools/                    Công cụ kiểm tra tùy chọn
  README.md / AI_USAGE.md / TU_KIEM_TRA.md
kiem-dinh/                  Kết quả kiểm tra gói
```

Mở index.html bằng Chrome/Edge hiện đại có :has(), hoặc tại thư mục ma-nguon chạy `python3 -m http.server 8892 --bind 127.0.0.1` rồi mở máy chủ cục bộ trên chính máy đó. Mở file trực tiếp cần sinh viên tự thử trên thiết bị trình bày; phiên kiểm tra dùng HTTP. Không cần npm, API key hoặc backend để xem trang. Công cụ Python trong tools/ là tùy chọn, không phải phụ thuộc chạy trang.

Trước khi nộp, tự xem giao diện 1366/768/390 px, thử lọc/đặt lại/chi tiết/hover/focus, làm một thay đổi nhỏ có lý do và ghi kết quả. Khi đổi dữ liệu giá cần sửa đồng nhất HTML và products.json. Khi luyện đổi cột/padding/gap phải lưu ý media query phía sau đang ghi đè ở độ rộng nào.

## 8.3. Đánh giá và định hướng Buổi 3

Nội dung tám bước đã được triển khai trên cùng khu vực, có bằng chứng và kết quả kiểm tra; bảy câu chính, bảy câu tự kiểm tra và năm dạng sửa trực tiếp được giải thích theo mã thật. Phần cá nhân cần sinh viên tự thực hiện và diễn đạt lại. Các kết quả đo xác nhận trong điều kiện đã thử, chưa chứng minh hiệu quả bán hàng hoặc toàn bộ trải nghiệm người dùng.

Hướng Buổi 3 là bổ sung JavaScript cho tìm kiếm, lọc/sắp xếp theo dữ liệu và thêm sản phẩm vào giỏ. Không thực hiện trước các chức năng đó trong bài Buổi 2. Các lớp, thuộc tính nhóm và cấu trúc bốn thẻ hiện tại là nền tảng tiếp tục, nhưng số đếm/giá vẫn là nội dung tĩnh.

## 8.4. Nguồn và minh chứng

1. TS. Nguyễn Mạnh Tuấn. **Buổi 2: HTML & CSS — Bài tập cá nhân**, BaiTap_CaNhan_Buoi2.pdf, 23 trang, do người dùng cung cấp. Căn cứ trực tiếp cho tám bước, câu hỏi và yêu cầu nộp.
2. Phong Select, mã Buổi 1 trong repository phong26052006-design/BT_canhanPTUDTMDT, commit dbb6bc2. Căn cứ kế thừa và ảnh trước.
3. Mã Buổi 2 commit afdd5c8; log và ảnh evidence/buoi2, ngày 22/10/2026. Căn cứ số đo, kiểm thử và kết quả sau sửa.
4. AI_USAGE.md và docs/buoi2/AI_USAGE.md. Nhật ký yêu cầu, khung prompt, kết quả và giới hạn vai trò.

Không dùng infographic của đề làm ảnh kết quả riêng. Các ảnh trong báo cáo là chụp thật của Phong Select hoặc thí nghiệm DOM được ghi rõ. Nguồn Lazada của Buổi 1 giữ riêng ở evidence/khao-sat, không gán là khảo sát mới của Buổi 2.

# Phụ lục — Phiếu thực hành cá nhân

Sinh viên hoàn thành bằng thao tác thật trên máy mình. Những dòng trống không phải lỗi xuất bản; chúng tránh xác nhận thay yêu cầu cá nhân ở mục 11 của đề.

| Nội dung | Sinh viên tự ghi |
|---|---|
| Ngày, editor, thiết bị và trình duyệt | ..................................................................... |
| Kích thước màn hình đã tự kiểm tra | ..................................................................... |
| Vấn đề bản thân phát hiện | ..................................................................... |
| Nguyên nhân đã xác định hoặc giả thuyết | ..................................................................... |
| Tệp, phần tử/selector và giá trị trước → sau | ..................................................................... |
| Dự đoán trước khi chạy | ..................................................................... |
| Kết quả sau sửa | ..................................................................... |
| Ảnh hoặc commit cá nhân | ..................................................................... |
| Giải thích vai trò HTML/CSS đã sửa | ..................................................................... |

Có thể điền trong Word hoặc TU_KIEM_TRA.md; khi chỉnh báo cáo Word hãy xuất lại PDF để nhất quán. Chuẩn bị giải thích ít nhất ba phần tử HTML và luyện năm tình huống sửa mã trước khi trình bày.
