# Bàn giao bài tập cá nhân Buổi 2

**Trương Thanh Phong · 31241024967 · EE0002 · 22/10/2026 — Bản rà soát cuối**

Đã đính chính phần giải thích width:auto/Box Model, chuẩn hóa khoảng trắng và kiểm tra lại tệp bàn giao. Bản Word trên GitHub được cập nhật tại cùng đường dẫn; ZIP có hậu tố BanCuoi.

## 1. Các tệp chính

- `BaiTap_Buoi2_TruongThanhPhong_31241024967.docx`: bản chỉnh sửa/nộp, đủ tám bước, câu hỏi, sửa trực tiếp và nhật ký AI.
- Tệp `.pdf` cùng tên: bản đọc/in đã kiểm tra trình bày.
- `BAO_CAO.md` và `BAO_CAO.html`: nội dung nguồn và bản xem/in; HTML cần giữ cạnh thư mục ma-nguon để tải ảnh.
- `ma-nguon/index.html`: giao diện Buổi 2, tiếp tục cùng Phong Select.
- `ma-nguon/css/style.css`: CSS chính. Root style.css chỉ tương thích đường dẫn cũ.
- `ma-nguon/docs/buoi2/`: bảng rà soát, bảy câu chính + bảy câu tự kiểm tra, năm tình huống sửa trực tiếp, chín khung prompt AI và kiểm thử.
- `ma-nguon/evidence/buoi2/`: ảnh trước/sau, ảnh trạng thái, thí nghiệm và log máy.
- `de-bai/BaiTap_CaNhan_Buoi2.pdf`: đề gốc người dùng cung cấp, để đối chiếu.
- `kiem-dinh/`: kết quả kiểm tra báo cáo/gói bàn giao.

## 2. Mở và thử giao diện

Giải nén, mở ma-nguon/index.html bằng Chrome/Edge hiện đại hỗ trợ CSS :has(). Bản kiểm thử dùng máy chủ HTTP tại thư mục ma-nguon:

```bash
python3 -m http.server 8892 --bind 127.0.0.1
```

Mở máy chủ cục bộ trên chính máy chạy Python. Không cần npm, framework hoặc tài khoản để xem trang. Thử chọn nhóm, đặt lại, mở thông tin, Xem hình lớn, hover và Tab/Enter; kiểm tra 1366/768/390 px. Lượt tự mở file trực tiếp cần bạn thử trên thiết bị của mình.

## 3. Bằng chứng và phạm vi

Mã nguồn giữ bốn sản phẩm, giá và SVG của Buổi 1. Buổi 2 sửa cấu trúc ul/li, CSS/Box Model/Flexbox, phản hồi hover/focus và có liên kết ảnh thật. Chưa thêm JavaScript ứng dụng, giỏ hàng, thanh toán hay backend.

Kiểm tra: bảy độ rộng, 21 trường hợp lọc, đặt lại/bàn phím, bốn liên kết ảnh, HTML/CSS/tài nguyên; thử Flexbox ba cách, Grid hai/ba cột và năm dạng sửa trực tiếp. Lượt rà soát cuối bổ sung 14 chiều rộng sát breakpoint, cả khi mở toàn bộ thông tin, kiểm tra focus liên kết ảnh, đối chiếu đầy đủ giá HTML và thí nghiệm width/box-sizing. Xem `ma-nguon/docs/buoi2/RA_SOAT_CUOI.md` và log trong `ma-nguon/evidence/buoi2/final-review/`. Ảnh flex/grid/practice là thí nghiệm tạm, không nhầm thành CSS cuối. Xem ui-check.json và KIEM_THU.md để biết phạm vi/giới hạn; kết quả axe không phải chứng nhận WCAG đầy đủ.

## 4. Phần sinh viên tự thực hiện theo đề

Đề yêu cầu bạn tự mở, tự phát hiện và sửa ít nhất một điểm, giải thích mã. Các việc trợ lý đã làm được ghi đúng vai trò, không xác nhận thay bạn. Hoàn thành `ma-nguon/TU_KIEM_TRA.md` hoặc phiếu cuối Word bằng ngày, vấn đề, nguyên nhân, giá trị trước/sau, dự đoán, kết quả và ảnh/commit thật.

Luyện năm yêu cầu ở `SUA_MA_TRUC_TIEP.md`. Khi đổi padding/cột/gap, xem đúng media query đang áp dụng. Khi sửa Word để bổ sung phần cá nhân, xuất lại PDF từ Word để hai bản nhất quán.

## 5. GitHub

Repository cùng Buổi 1: https://github.com/phong26052006-design/BT_canhanPTUDTMDT

Mã Buổi 2 và tài liệu đã đẩy lên main; báo cáo Word nằm trong bao-cao/. Kiểm tra công khai chi tiết ở GITHUB_PUBLISH.md và kiem-dinh/artifact-check.json.

Chưa xác minh có GitHub Pages hoạt động (API đọc trả 404 ngày 22/10). Repository Public cho xem mã/tài liệu; để có website trực tiếp, cần bật Settings → Pages, main, /(root), chờ triển khai và mở URL GitHub cấp. Không dùng URL dự kiến làm bằng chứng website đã chạy.

## 6. Toàn vẹn gói

SHA256SUMS.txt ghi mã băm từng tệp, trừ chính danh sách. Gói không chứa thư mục .git, cache Python, thư viện kiểm tra đã cài trong môi trường, token, cookie hoặc tài liệu riêng của người khác. Các báo cáo/ảnh Buổi 1 trong mã nguồn là lịch sử tham khảo, không được tính thay ảnh Buổi 2.
